/* ============================================================
   Smart Home Dashboard – dashboard.js
   ============================================================ */

// --- Orologio in tempo reale nel topbar ---
function updateClock() {
    const el = document.getElementById('clock');
    if (el) el.textContent = new Date().toLocaleString('it-IT');
}
setInterval(updateClock, 1000);
updateClock();

// --- Configurazione sensori ---
var SENSORS = [
    { name: '01_occ',        label: 'Occupancy' },
    { name: '02_win',        label: 'Windows' },
    { name: '03_light',      label: 'Light (Luce)' },
    { name: '04_plug',       label: 'Plug Loads [W]' },
    { name: '05_temp_in',    label: 'Temp. Interna [C]' },
    { name: '06_rhu_in',     label: 'Umidità Interna [%]' },
    { name: '07_rad_global', label: 'Radiazione Globale [W/m2]' },
    { name: '08_temp_out',   label: 'Temp. Esterna [C]' },
    { name: '09_rhu_out',    label: 'Umidità Esterna [%]' },
    { name: '10_wsp',        label: 'Velocità Vento [m/s]' },
    { name: '11_wdi',        label: 'Direzione Vento [°]' },
];

// --- Popola il select del sensore ---
function populateSensorSelect() {
    var sel = document.getElementById('sensor-select');
    if (!sel) return;
    SENSORS.forEach(function(s) {
        var opt = document.createElement('option');
        opt.value = s.name;
        opt.textContent = s.label;
        sel.appendChild(opt);
    });
}

// --- Carica e disegna il grafico del sensore selezionato ---
function loadChart() {
    var sensorName = document.getElementById('sensor-select').value;
    var limit      = parseInt(document.getElementById('rows-select').value);
    var container  = document.getElementById('chart-container');

    if (!sensorName) {
        container.innerHTML = '<p class="empty-state">Seleziona un sensore.</p>';
        return;
    }

    container.innerHTML = '<p class="empty-state">Caricamento…</p>';

    $.getJSON('/sensors/' + sensorName, function(data) {
        if (!data || data.length === 0) {
            container.innerHTML = '<p class="empty-state">Nessun dato disponibile per questo sensore.</p>';
            return;
        }

        // Prende le ultime N righe
        var slice = data.slice(-limit);

        var columns = Object.keys(slice[0][2]);
        var header  = ['Timestamp'].concat(columns);
        var chartRows = [header];

        slice.forEach(function(entry) {
            var row = [entry[1]];
            columns.forEach(function(col) {
                row.push(parseFloat(entry[2][col]) || 0);
            });
            chartRows.push(row);
        });

        container.innerHTML = '';
        container.style.minHeight = '320px';

        google.charts.setOnLoadCallback(function() {
            var dataTable = google.visualization.arrayToDataTable(chartRows);
            var sensor    = SENSORS.find(function(s) { return s.name === sensorName; });
            var options   = {
                title: sensor ? sensor.label : sensorName,
                titleTextStyle: { fontName: 'DM Sans', fontSize: 14, bold: true, color: '#1e293b' },
                hAxis: { title: 'Timestamp', textStyle: { fontName: 'DM Sans', fontSize: 11 } },
                vAxis: { minValue: 0,         textStyle: { fontName: 'DM Sans', fontSize: 11 } },
                legend: { position: 'bottom',  textStyle: { fontName: 'DM Sans', fontSize: 12 } },
                chartArea: { left: 60, right: 20, top: 40, bottom: 80, width: '100%', height: '100%' },
                colors: ['#3b82f6','#22c55e','#f59e0b','#ef4444','#8b5cf6','#06b6d4'],
                backgroundColor: 'transparent',
                areaOpacity: 0.15,
            };
            var chart = new google.visualization.AreaChart(container);
            chart.draw(dataTable, options);
        });

    }).fail(function() {
        container.innerHTML = '<p class="empty-state">Errore nel caricamento dei dati.</p>';
    });
}

// --- Aggiorna la tabella dei sensori attivi ---
function loadSensorTable() {
    $.getJSON('/sensors', function(list) {
        document.getElementById('sensor-count').textContent = list.length;

        var tbody = document.getElementById('sensor-tbody');
        tbody.innerHTML = '';

        if (list.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#64748b;">Nessun sensore attivo</td></tr>';
            return;
        }

        var pending = list.length;
        list.forEach(function(sName) {
            $.getJSON('/sensors/' + sName, function(data) {
                var label  = (SENSORS.find(function(s) { return s.name === sName; }) || {}).label || sName;
                var last   = data && data.length ? data[data.length - 1] : null;
                var ts     = last ? last[1] : '—';
                var vals   = last ? Object.values(last[2]).slice(0,2).join(', ') : '—';

                var tr = document.createElement('tr');
                tr.innerHTML =
                    '<td>' + label + '</td>' +
                    '<td>' + vals  + '</td>' +
                    '<td>' + ts    + '</td>';
                tbody.appendChild(tr);
            });
        });
    });
}

// --- Mappa della smart home (SVG colorata per occupazione) ---
function loadFloorplan() {
    var roomMap = {
        'room_ki': 'ki [0:vacant 1:occupied]',
        'room_o1': 'o1_1 [0:vacant 1:occupied]',
        'room_o2': 'o2 [0:vacant 1:occupied]',
        'room_o3': 'o3 [0:vacant 1:occupied]',
        'room_o4': 'o4 [0:vacant 1:occupied]',
    };

    $.getJSON('/sensors/01_occ', function(data) {
        if (!data || data.length === 0) return;
        var values = data[data.length - 1][2];
        $.each(roomMap, function(roomId, colName) {
            var val   = values[colName];
            var color = '#b3d4f0';                    // grigio-blu = nessun dato
            if (val === '1') color = '#90caf9';       // azzurro = occupata
            if (val === '0') color = '#fecaca';       // rosso chiaro = libera
            document.getElementById(roomId).setAttribute('fill', color);
        });
    });
}

// --- Aggiorna timestamp ---
function updateLastUpdate() {
    var el = document.getElementById('last-update');
    if (el) el.textContent = new Date().toLocaleString('it-IT');
}

// --- Init ---
$(document).ready(function() {
    google.charts.load('current', { packages: ['corechart'] });

    populateSensorSelect();
    loadChart();
    loadSensorTable();
    loadFloorplan();
    updateLastUpdate();

    document.getElementById('btn-refresh').addEventListener('click', loadChart);

    // Auto-refresh ogni 5 secondi
    setInterval(function() {
        loadChart();
        loadSensorTable();
        loadFloorplan();
        updateLastUpdate();
    }, 5000);
});